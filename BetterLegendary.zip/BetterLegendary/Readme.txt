Updated for 1.1.7.7
Updated the extract with previous values from https://www.nexusmods.com/wolcenlordsofmayhem/mods/54 and https://www.nexusmods.com/wolcenlordsofmayhem/mods/15

Allows for Legendarys to rolls Unique affix
Updated rarity and item quanitity
Updated suffix and affix counts
Misc other updates to match old values

Copy Umbra folder to your WolcenDirectory\Game

THe game will read the folder first for values

Credits to Neurosis404 and vicious187